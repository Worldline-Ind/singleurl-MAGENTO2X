<?php


namespace Techprocess\Paynimo\Block\Redirect;




class Index extends \Magento\Framework\View\Element\Template
{

    
}